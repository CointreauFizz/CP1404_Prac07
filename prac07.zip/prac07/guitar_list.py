
from guitar import Guitar


def main():
    print("your personal guitar list")
    guitar = []
    add_new_guitar(guitar)


def list_guitar(guitar):
    list_index = 1
    for guitar in guitar:
        print("Guitar {}: {:>20} ({}), worth ${:10,.2f} ({})".format(
            list_index, guitar.name, guitar.year, guitar.cost,
            "vintage" if (guitar.is_vintage() is True) else ""))
        list_index += 1


def add_new_guitar(guitar):
    while True:
        name = input("Guitar Name: ")
        if not name:
            list_guitar(guitar)
            raise SystemExit(0)
        else:
            year = input("Production year of your guitar: ")
            cost = input("Cost of your guitar: ")
            new_guitar = Guitar(name, int(year), int(cost))
            guitar.append(new_guitar)
            print("{} ({}): {} added to guitar list".format(name, year, cost))


if __name__ == '__main__':
        main()
